
Quick installation::

  pip install iching

Quick Start::

  from iching import iching
  
  iching.predict(19850927, 20180119)
